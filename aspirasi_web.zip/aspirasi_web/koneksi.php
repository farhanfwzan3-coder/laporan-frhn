<?php
$conn = mysqli_connect("localhost","root","","aspirasi_web");

if(!$conn){
die("Koneksi gagal");
}
?>