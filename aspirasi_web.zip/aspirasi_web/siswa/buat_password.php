<?php
session_start();
include "../koneksi.php";

if(!isset($_SESSION['nis'])){
header("location:../index.php");
exit;
}

if(isset($_POST['simpan'])){

$nis = $_SESSION['nis'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

mysqli_query($conn,"UPDATE siswa SET password='$password' WHERE nis='$nis'");

header("location:dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Buat Password</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Buat Password</h2>

<form method="POST">

<input type="password" name="password" placeholder="Buat password" required>

<button name="simpan" class="btn">Simpan</button>

</form>

</div>

</body>
</html>