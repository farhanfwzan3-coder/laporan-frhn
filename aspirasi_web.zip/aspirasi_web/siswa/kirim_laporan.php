<?php
session_start();
include "../koneksi.php";

if(!isset($_SESSION['nis'])){
  header("location:../index.php");
  exit;
}

if(isset($_POST['kirim'])){

  $nis = $_SESSION['nis'];
  $kategori = $_POST['kategori'];
  $lokasi = $_POST['lokasi'];
  $ket = $_POST['ket'];
  $tanggal = date("Y-m-d");

  $foto = $_FILES['foto']['name'];
  $tmp  = $_FILES['foto']['tmp_name'];

  $folder = "../uploads/" . $foto;

  if(move_uploaded_file($tmp, $folder)){

    mysqli_query($conn,"INSERT INTO pelaporan 
    (nis,kategori,lokasi,ket,tanggal,foto,status_baca,status,feedback) 
    VALUES
    ('$nis','$kategori','$lokasi','$ket','$tanggal','$foto','0','menunggu','')");

    $notif = "success";
  } else {
    $notif = "error";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Kirim Laporan</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Kirim Laporan</h2>

<?php if(isset($notif) && $notif=="success"){ ?>
<div class="notif success">Laporan berhasil dikirim!</div>
<?php } ?>

<?php if(isset($notif) && $notif=="error"){ ?>
<div class="notif error">Upload gagal! </div>
<?php } ?>

<form method="POST" enctype="multipart/form-data">

<input type="text" name="kategori" placeholder="Kategori" required>

<input type="text" name="lokasi" placeholder="Lokasi" required>

<textarea name="ket" placeholder="Keterangan" required></textarea>

<input type="file" name="foto" required>

<button name="kirim" class="btn">Kirim</button>

</form>

<br>
<a href="dashboard.php" class="btn">← Kembali</a>

</div>

</body>
</html>