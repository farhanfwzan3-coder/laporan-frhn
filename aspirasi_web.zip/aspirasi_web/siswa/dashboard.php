<?php
session_start();
if(!isset($_SESSION['nis'])){
header("location:../index.php");
exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Siswa</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Dashboard Siswa</h2>

<a href="kirim_laporan.php" class="btn">Kirim Laporan</a><br><br>
<a href="riwayat_laporan.php" class="btn">Riwayat Laporan</a><br><br>
<a href="../logout.php" class="btn">Logout</a>

</div>

</body>
</html>