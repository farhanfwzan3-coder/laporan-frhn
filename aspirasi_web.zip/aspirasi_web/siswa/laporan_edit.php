<?php
session_start();
include "../koneksi.php";

$id=$_GET['id'];

$data=mysqli_query($conn,"SELECT * FROM pelaporan WHERE id_pelaporan='$id'");
$d=mysqli_fetch_array($data);

if(isset($_POST['update'])){

$lokasi=$_POST['lokasi'];
$ket=$_POST['ket'];

mysqli_query($conn,"UPDATE pelaporan SET lokasi='$lokasi',ket='$ket' WHERE id_pelaporan='$id'");

header("location:riwayat_laporan.php");
}
?>

<h2>Edit Laporan</h2>

<form method="POST">

Lokasi<br>
<input type="text" name="lokasi" value="<?php echo $d['lokasi']; ?>"><br><br>

Keterangan<br>
<textarea name="ket"><?php echo $d['ket']; ?></textarea><br><br>

<button name="update">Update</button>

</form>
