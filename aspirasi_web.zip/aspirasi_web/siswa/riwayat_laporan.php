<?php
session_start();
include "../koneksi.php";

$nis = $_SESSION['nis'];

$data = mysqli_query($conn,"SELECT * FROM pelaporan WHERE nis='$nis'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Riwayat Laporan</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Riwayat Laporan</h2>

<table>
<tr>
<th>ID</th>
<th>Lokasi</th>
<th>Status</th>
</tr>

<?php while($d=mysqli_fetch_array($data)){ ?>

<tr>
<td><?php echo $d['id_pelaporan']; ?></td>
<td><?php echo $d['lokasi']; ?></td>
<td><?php echo $d['status']; ?></td>
</tr>

<?php } ?>

</table>

<br>
<a href="dashboard.php" class="btn">← Kembali</a>

</div>

</body>
</html>