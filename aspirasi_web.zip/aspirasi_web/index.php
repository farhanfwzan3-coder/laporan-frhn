<?php include "auth.php"; ?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

<h2>Login Siswa</h2>

<?php if(!empty($notif)) echo $notif; ?>

<form method="POST">

<input type="text" name="nis" placeholder="NIS" required>
<input type="password" name="password" placeholder="Password">

<button type="submit" name="login" class="btn">Login</button>

</form>

</div>

</body>
</html>