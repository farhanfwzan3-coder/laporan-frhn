<?php
session_start();
include "koneksi.php";

$notif = "";

if(isset($_POST['login'])){

$nis = $_POST['nis'];
$password = $_POST['password'];

$data = mysqli_query($conn,"SELECT * FROM siswa WHERE nis='$nis'");
$d = mysqli_fetch_array($data);

if($d){

if($d['password'] == NULL || $d['password'] == ''){
$_SESSION['nis'] = $d['nis'];
header("location:siswa/buat_password.php");
exit;

}else{

if(password_verify($password, $d['password'])){
$_SESSION['nis'] = $d['nis'];
header("location:siswa/dashboard.php");
exit;
}else{
$notif = "<div class='notif error'>Password salah!</div>";
}

}

}else{
$notif = "<div class='notif error'>NIS tidak ditemukan!</div>";
}

}
?>