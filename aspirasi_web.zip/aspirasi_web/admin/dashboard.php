<?php
include "../koneksi.php";

$jml_siswa = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM siswa"));
$jml_laporan = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM pelaporan"));
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Admin</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Dashboard Admin</h2>

<div class="notif info">Jumlah Siswa: <?php echo $jml_siswa; ?></div>
<div class="notif success">Total Laporan: <?php echo $jml_laporan; ?></div>

<br>

<a href="laporan.php" class="btn">Data Laporan</a><br><br>
<a href="../index.php" class="btn">Kembali</a>

</div>

</body>
</html>