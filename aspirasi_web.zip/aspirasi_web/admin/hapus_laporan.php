<?php
include "../koneksi.php";

$id = $_GET['id'];

$data = mysqli_query($conn,"SELECT foto FROM pelaporan WHERE id_pelaporan='$id'");
$d = mysqli_fetch_array($data);

if($d['foto'] != ''){
unlink("../uploads/".$d['foto']);
}

mysqli_query($conn,"DELETE FROM pelaporan WHERE id_pelaporan='$id'");

// kembali
header("location:laporan.php");
?>