<?php
include "../koneksi.php";

$data=mysqli_query($conn,"SELECT * FROM pelaporan");
?>

<!DOCTYPE html>
<html>
<head>
<title>Data Laporan</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Data Laporan</h2>

<table border="1">
<tr>
<th>ID</th>
<th>NIS</th>
<th>Lokasi</th>
<th>Status</th>
<th>Detail</th>
<th>Hapus</th>
</tr>

<?php while($d=mysqli_fetch_array($data)){ ?>

<tr>
<td><?php echo $d['id_pelaporan']; ?></td>
<td><?php echo $d['nis']; ?></td>
<td><?php echo $d['lokasi']; ?></td>
<td><?php echo $d['status']; ?></td>

<td>
<a href="laporan_detail.php?id=<?php echo $d['id_pelaporan']; ?>">Detail</a>
</td>

<td>
<a href="hapus_laporan.php?id=<?php echo $d['id_pelaporan']; ?>" 
onclick="return confirm('Yakin hapus?')">
Hapus
</a>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>