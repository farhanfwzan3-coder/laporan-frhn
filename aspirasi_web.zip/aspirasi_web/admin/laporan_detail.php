<?php
include "../koneksi.php";

$id=$_GET['id'];

$data=mysqli_query($conn,"SELECT * FROM pelaporan WHERE id_pelaporan='$id'");
$d=mysqli_fetch_array($data);

mysqli_query($conn,"UPDATE pelaporan SET status_baca='1' WHERE id_pelaporan='$id'");
?>

<!DOCTYPE html>
<html>
<head>
<title>Detail Laporan</title>
<link rel="stylesheet" href="../style.css">
</head>

<body>

<div class="container">

<h2>Detail Laporan</h2>

Kategori : <?php echo $d['kategori']; ?><br>
Lokasi : <?php echo $d['lokasi']; ?><br>
Keterangan : <?php echo $d['ket']; ?><br><br>

<img src="../uploads/<?php echo $d['foto']; ?>" width="200"><br><br>

<form method="POST" action="laporan_update.php">

<input type="hidden" name="id" value="<?php echo $d['id_pelaporan']; ?>">

Status<br>
<select name="status">
<option>menunggu</option>
<option>diproses</option>
<option>selesai</option>
</select><br><br>

Feedback<br>
<textarea name="feedback"></textarea><br><br>

<button name="update" class="btn">Update</button>

</form>

</div>

</body>
</html>