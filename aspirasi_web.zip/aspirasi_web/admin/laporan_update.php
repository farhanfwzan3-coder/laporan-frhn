<?php
include "../koneksi.php";

$id=$_POST['id'];
$status=$_POST['status'];
$feedback=$_POST['feedback'];

mysqli_query($conn,"UPDATE pelaporan SET status='$status',feedback='$feedback' WHERE id_pelaporan='$id'");

header("location:laporan.php");
?>